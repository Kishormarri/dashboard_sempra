import openpyxl
import json
import os

def da_parse(path):
    print(f"Reading {path}...")
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows: return []
    headers = [str(h).strip() if h is not None else f'col_{i}' for i, h in enumerate(rows[0])]
    result = []
    for r in rows[1:]:
        if not any(r): continue
        d = {}
        for h, val in zip(headers, r):
            d[h] = val
        result.append(d)
    return result

def da_dc(headers, candidates):
    for c in candidates:
        for h in headers:
            if h.upper() == c.upper(): return h
    for c in candidates:
        for h in headers:
            if c.upper() in h.upper(): return h
    return None

def da_dtc(headers):
    for h in headers:
        hu = h.upper()
        if any(k in hu for k in ['TABLE_NAME','TABLENAME','TABLE NAME','TABNAME','TABLE','OBJECT']):
            return h
    return headers[0] if headers else ''

def da_n(val):
    if val is None or val == '': return None
    try:
        s = str(val).replace(',', '').strip()
        f = float(s)
        return int(f) if f.is_integer() else f
    except: return None

def da_analyse(cycle, refRows, expRows):
    hdrs = list(refRows[0].keys()) if refRows else []
    tblC = da_dtc(hdrs)
    srcC = da_dc(hdrs, ['SOURCE_COUNT','SOURCE COUNT','SRC_COUNT','SRC_RECORDS','SOURCE_TOTAL','SOURCE'])
    tgtC = da_dc(hdrs, ['TARGET_COUNT','TARGET COUNT','TGT_COUNT','TGT_RECORDS','TARGET_TOTAL','TARGET'])
    refMap = {}
    for rr in refRows:
        k = str(rr.get(tblC, '') or '').strip().upper()
        if not k: continue
        if k not in refMap: refMap[k] = {'name': rr.get(tblC), 'src': None, 'tgt': None}
        s = da_n(rr.get(srcC)) if srcC else None
        t = da_n(rr.get(tgtC)) if tgtC else None
        if s is not None: refMap[k]['src'] = (refMap[k]['src'] or 0) + s
        if t is not None: refMap[k]['tgt'] = (refMap[k]['tgt'] or 0) + t

    expMap = {}
    impMap = {}
    if expRows:
        eh = list(expRows[0].keys())
        etc = da_dc(eh, ['TABLE_NAME','TABLENAME','TABLE NAME','TABNAME','TABLE','OBJECT']) or (eh[0] if eh else '')
        ecc = da_dc(eh, ['RECORD_COUNT','RECORD COUNT','RECORDS','COUNT','TOTAL_RECORDS','NROWS','ENTRIES','ROW_COUNT'])
        eTypeC = None
        for cand in ['TYPE','MIGTYPE','MIGRATION TYPE','MIGRATION_TYPE','MOVE_TYPE','MOVETYPE','TRANS_TYPE']:
            if cand in [x.upper() for x in eh]:
                for x in eh:
                    if x.upper() == cand: eTypeC = x; break
                break
        if not eTypeC:
            for x in eh:
                if 'TYPE' in x.upper(): eTypeC = x; break
        
        daSeen = {}
        for er in expRows:
            et = str(er.get(eTypeC, '') or '').strip().upper() if eTypeC else ''
            if eTypeC and et not in ('EXP', 'IMP'): continue
            ek = str(er.get(etc, '') or '').strip().upper()
            if not ek: continue
            ev = da_n(er.get(ecc)) or 0 if ecc else 0
            dadk = f"{et if eTypeC else 'EXP'}|{ek}|{ev}"
            if dadk in daSeen: continue
            daSeen[dadk] = True
            if not eTypeC or et == 'EXP':
                expMap[ek] = expMap.get(ek, 0) + ev
            else:
                impMap[ek] = impMap.get(ek, 0) + ev

    refKeys = list(refMap.keys())
    rklen = len(refKeys)
    eiSeen = {}
    tdata = []
    compactRows = []
    for k2 in refKeys:
        eiSeen[k2] = True
        ref = refMap[k2]
        e = expMap.get(k2)
        im = impMap.get(k2)
        stD = (ref['src'] - ref['tgt']) if (ref['src'] is not None and ref['tgt'] is not None) else None
        eiD = (e - im) if (e is not None and im is not None) else None
        stOk = (stD == 0) if stD is not None else None
        eiOk = (eiD == 0) if eiD is not None else None
        ov = 'PARTIAL'
        if stOk is True and eiOk is True: ov = 'ALL_OK'
        elif stOk is False and eiOk is False: ov = 'BOTH_DIFF'
        elif stOk is False: ov = 'SRC_TGT_DIFF'
        elif eiOk is False: ov = 'EXP_IMP_DIFF'
        elif eiOk is True: ov = 'EI_OK' if stOk is None else 'ALL_OK'
        elif e is not None and im is None: ov = 'EXP_ONLY'
        elif e is None and im is not None: ov = 'IMP_ONLY'
        tdata.append({'stOk': stOk, 'eiOk': eiOk, 'overall': ov, 'exp': e, 'imp': im})
        compactRows.append([ref['name'], k2, ref['src'], ref['tgt'], e, im, 1])

    expOnlyN = 0
    impOnlyN = 0
    xk2 = list(set(list(expMap.keys()) + list(impMap.keys())))
    for xk in xk2:
        inRef = xk in refMap
        xe = expMap.get(xk)
        xim = impMap.get(xk)
        if not inRef:
            if xe is not None: expOnlyN += 1
            if xim is not None: impOnlyN += 1
        if xk in eiSeen: continue
        eiSeen[xk] = True
        xeiD = (xe - xim) if (xe is not None and xim is not None) else None
        xeiOk = (xeiD == 0) if xeiD is not None else None
        tdata.append({'stOk': None, 'eiOk': xeiOk, 'overall': 'EXP_ONLY', 'exp': xe, 'imp': xim})
        if not inRef:
            compactRows.append([xk, xk, None, None, xe, xim, 0])

    stOkN = sum(1 for kr in tdata if kr['stOk'] is True)
    stFaN = sum(1 for kr in tdata if kr['stOk'] is False)
    eiOkN = sum(1 for kr in tdata if kr['eiOk'] is True)
    eiFaN = sum(1 for kr in tdata if kr['eiOk'] is False)
    reconN = sum(1 for kr in tdata if kr['overall'] in ('ALL_OK', 'EI_OK'))
    hasExp = bool(expRows)
    hasImp = bool(impMap)
    pct = round((reconN / len(tdata)) * 100) if (tdata and hasExp and hasImp) else 0
    expTot = sum(expMap.values())
    impTot = sum(impMap.values())
    srcTot = sum(refMap[k]['src'] or 0 for k in refKeys)
    tgtTot = sum(refMap[k]['tgt'] or 0 for k in refKeys)

    cvSeOk = sum(1 for k in refKeys if refMap[k]['src'] is not None and expMap.get(k) is not None and refMap[k]['src'] == expMap.get(k))
    cvTiOk = sum(1 for k in refKeys if refMap[k]['tgt'] is not None and impMap.get(k) is not None and refMap[k]['tgt'] == impMap.get(k))
    refInExpN = sum(1 for k in refKeys if k in expMap)
    refInImpN = sum(1 for k in refKeys if k in impMap)

    return {
        'kTotal': rklen, 'kPct': f"{pct}%",
        'kExp': len(expMap), 'kImp': len(impMap),
        'kExpOnly': expOnlyN, 'kImpOnly': impOnlyN,
        'kSTok': stOkN, 'kSTfail': stFaN,
        'kEIok': eiOkN, 'kEIfail': eiFaN,
        'cvSeOk': cvSeOk, 'cvSeTot': rklen,
        'cvTiOk': cvTiOk, 'cvTiTot': rklen,
        'refInExp': refInExpN, 'refInImp': refInImpN,
        'refMissExp': rklen - refInExpN, 'refMissImp': rklen - refInImpN,
        'expTotalRec': expTot, 'impTotalRec': impTot,
        'srcTotalRec': srcTot, 'tgtTotalRec': tgtTot,
        'reconN': reconN, 'tableN': len(tdata),
        '_refOnly': (not hasExp and not hasImp),
        '_cycle': cycle,
        'runStamp': '10/22/2026, 09:55:00 PM',
        '_compactRows': compactRows[:200]
    }

dm1 = da_analyse('DM1', da_parse(r'C:\Users\KishorMarri\.bob\DM1\Reflist_m1.xlsx'), da_parse(r'C:\Users\KishorMarri\.bob\DM1\DM1_ES2-SQ1 Export-Import.xlsx'))
dm2 = da_analyse('DM2', da_parse(r'C:\Users\KishorMarri\.bob\DM2\DM2 REF.xlsx'), da_parse(r'C:\Users\KishorMarri\.bob\DM2\EXPORT IMPORT_DM2.xlsx'))
dm3 = da_analyse('DM3', da_parse(r'C:\Users\KishorMarri\.bob\DM3\ref dm31.xlsx'), da_parse(r'C:\Users\KishorMarri\.bob\DM3\DM3 EXPORT IMPORT LOG_20261018.xlsx'))

summary = {'DM1': dm1, 'DM2': dm2, 'DM3': dm3}
with open('embedded_baseline_data.json', 'w') as f:
    json.dump(summary, f)

print("EXTRACTION SUCCESSFUL")
print("DM1:", dm1['kTotal'], dm1['kPct'])
print("DM2:", dm2['kTotal'], dm2['kPct'])
print("DM3:", dm3['kTotal'], dm3['kPct'])
