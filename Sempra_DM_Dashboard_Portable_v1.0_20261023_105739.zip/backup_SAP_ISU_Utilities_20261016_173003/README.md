﻿# SAP IS-U / CIS Utilities Reference — Backup
Created: 2026-10-16 17:30:03

## Files
1. SAP_ISU_Reference_Hub.html         — Master launcher (links all tools)
2. SAP_ISU_Emigall_Reference.html     — 43 migration objects, cutover dashboard, QA
3. SAP_ISU_Architecture_Reference.html — Architecture, load sequence, 60+ T-codes
4. SAP_ISU_CIS_UtilityTypes_Reference.html — 6 utility types, 11 device types
5. SAP_ISU_BillingSchema_Reference.html — TE006/TE400/TE423 billing schema

## Usage
Open SAP_ISU_Reference_Hub.html in any browser — no server or internet required.
All files are standalone HTML with zero external dependencies.

## Coverage
- EMIGALL: T7XEMI01-06, T7XEMERR, T7XEMLOG, BAdI, Test/Prod mode
- Objects: BP, CA, Connection Obj, Premise, Device, Meter Read, FI-CA, Billing
- Utility Types: Electric (E), Gas (G), Water (W), Waste Water (V), Steam (S), Street Lighting (D)
- Device Types: AMI, CT/PT, Net Meter, TOU, EVC Corrector, Virtual/Computed, Solar DER
- BODS: SharePoint -> BODS -> EMIGALL -> SAP IS-U full flow
- Billing: TE006 -> TE422 -> TE400 -> TE423 -> EVER -> ERDK -> DFKKOP chain
